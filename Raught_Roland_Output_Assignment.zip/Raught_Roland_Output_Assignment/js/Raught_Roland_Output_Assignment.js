/*!
 * Roland Raught
 7/9/15
 SDI Section 01
 Output Assignment
 *
 */

//testing connectivity
var name = prompt("Let\'s learn about Roland.\nPlease type in your name:");
console.log("Welcome "+name+".");

var aliasName = true; //Boolean variable

//added a string variable
var myName = "Jay";
console.log("My real name is Roland D.J.Raught III. I go by "+myName+" instead of my given name. The reason for this is four family members have the name Roland. To avoid confusing my father, grandfather and I, my mother used J initial to create the name Jay instead of Roland.");

var uncle = 8; //number variable
console.log("One more interesting tidbit is that I am an uncle of "+uncle+" nieces and nephews 6 boys and 2 girls!! I also have 3 children.");
